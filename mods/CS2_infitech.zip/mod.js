mod.addItem("plateNailed.js","normal");
//mod.addItem("plateNailedT2.js","normal");
//mod.addItem("plateNailedT3.js","normal");