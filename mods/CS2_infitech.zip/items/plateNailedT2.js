name = "plateNailedT2";
creativeTab = "materials";
maxStack = 64;

information[0] = "Tier 2";
addToCreative[0] = true;
textureFile[0] = "plateNailedT2.png"; 