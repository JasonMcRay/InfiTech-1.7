name = "plateNailedT3";
creativeTab = "materials";
maxStack = 64;

information[0] = "Tier 3";
addToCreative[0] = true;
textureFile[0] = "plateNailedT3.png"; 