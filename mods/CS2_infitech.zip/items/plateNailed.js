name = "plateNailed";
creativeTab = "materials";
maxStack = 64;

information[0] = "Tier 1";
information[1] = "Tier 2";
information[2] = "Tier 3";
addToCreative[0] = true;
addToCreative[1] = true;
addToCreative[2] = true;
textureFile[0] = "plateNailed.png";
textureFile[1] = "plateNailedT2.png"; 
textureFile[2] = "plateNailedT3.png"; 